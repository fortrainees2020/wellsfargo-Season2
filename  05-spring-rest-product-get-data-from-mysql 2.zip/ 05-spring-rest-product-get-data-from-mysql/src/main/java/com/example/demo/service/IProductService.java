package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Product;

public interface  IProductService {
	List<Product> findAllProducts() ;
	Product getProduct(int productNo);
	Optional<Product> getProductsFromDatabase(int productNo);
	List<Product> getAllProductsFromDatabase();
}


