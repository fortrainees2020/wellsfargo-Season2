package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
@Service
public class ProductService implements IProductService {
	ArrayList<Product> products = new ArrayList<Product>(); 
	
	@Override
	public List<Product> findAllProducts() {
		
		products.add(new Product(100, "Laptop", 9000.0));  
		products.add(new Product(101, "Smart TV", 60000.00));  
		products.add(new Product(102, "Mobile",  9000.00)); 		
		return products;
	}

	@Override
	public Product getProduct(int id) {
		products=(ArrayList<Product>) findAllProducts();
		for (Product product : products) {
	        if (product.getId()==id) {
	            return product;
	        }
		}
		    return null;
	}
	
	@Autowired
	ProductRepository productRepo;
	
	@Override
	public Optional<Product> getProductsFromDatabase(int productNo) {
		return productRepo.findById(productNo);
	}

	@Override
	public List<Product> getAllProductsFromDatabase() {
		return productRepo.findAll();
	}
	}
	

